const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const source=$('#source'), high=$('#highlight');
function paintCode(){let s=source.value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
s=s.replace(/(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,'<span class="comment">$1</span>')
.replace(/("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,'<span class="str">$1</span>')
.replace(/\b(if|else|for|while|repeat|switch|case|break|return|var|function|with|true|false|undefined|self|other|global)\b/g,'<span class="kw">$1</span>')
.replace(/\b(\d+(?:\.\d+)?)\b/g,'<span class="num">$1</span>')
.replace(/\b(keyboard_check|instance_create_layer|show_debug_message|draw_text|instance_destroy|place_meeting)\b/g,'<span class="fn">$1</span>');
high.innerHTML=s+'\n';high.scrollTop=source.scrollTop;high.scrollLeft=source.scrollLeft}
source.addEventListener('input',paintCode);source.addEventListener('scroll',()=>{high.scrollTop=source.scrollTop;high.scrollLeft=source.scrollLeft});paintCode();
source.addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();let a=source.selectionStart,b=source.selectionEnd;source.setRangeText('    ',a,b,'end');paintCode()}});
$$('#tabs button').forEach(b=>b.onclick=()=>{$$('#tabs button').forEach(x=>x.classList.toggle('active',x===b));$$('.page').forEach(p=>p.classList.toggle('active',p.id===b.dataset.page))});
$$('[data-insert]').forEach(b=>b.onclick=()=>{source.setRangeText('\n'+b.dataset.insert,source.selectionStart,source.selectionEnd,'end');paintCode()});
$('#snippet').onclick=()=>{source.setRangeText('\n\n// New event code\n',source.selectionStart,source.selectionEnd,'end');paintCode()};
let tool='pen',color=$('#color').value,grid=32,frames=1;const cv=$('#pixel'),ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
function pixelDraw(e){const r=cv.getBoundingClientRect(),x=Math.floor((e.clientX-r.left)/r.width*grid),y=Math.floor((e.clientY-r.top)/r.height*grid),sz=cv.width/grid;ctx.fillStyle=tool==='erase'?'rgba(0,0,0,0)':color;if(tool==='erase')ctx.clearRect(x*sz,y*sz,sz,sz);else ctx.fillRect(x*sz,y*sz,sz,sz)}
let drawing=false;cv.onpointerdown=e=>{drawing=true;cv.setPointerCapture(e.pointerId);pixelDraw(e)};cv.onpointermove=e=>{if(drawing)pixelDraw(e)};cv.onpointerup=()=>drawing=false;cv.onpointercancel=()=>drawing=false;
$$('[data-tool]').forEach(b=>b.onclick=()=>{$$('[data-tool]').forEach(x=>x.classList.toggle('selected',x===b));tool=b.dataset.tool});
$('#color').oninput=e=>color=e.target.value;$('#grid').onchange=e=>grid=+e.target.value;$('#clear').onclick=()=>ctx.clearRect(0,0,cv.width,cv.height);
$('#export').onclick=()=>{let a=document.createElement('a');a.download='spr_player.png';a.href=cv.toDataURL('image/png');a.click()};
$('#addframe').onclick=()=>{frames++;let b=document.createElement('button');b.className='frame';b.textContent=frames;b.onclick=()=>{$$('.frame').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')};$('#frames').append(b)};
const rc=$('#roomcanvas'),rx=rc.getContext('2d');let objects=[],showGrid=true,placing=false;
function drawRoom(){rx.fillStyle='#151f2b';rx.fillRect(0,0,640,420);if(showGrid){rx.strokeStyle='#283747';rx.lineWidth=1;for(let x=0;x<=640;x+=32){rx.beginPath();rx.moveTo(x,0);rx.lineTo(x,420);rx.stroke()}for(let y=0;y<=420;y+=32){rx.beginPath();rx.moveTo(0,y);rx.lineTo(640,y);rx.stroke()}}objects.forEach(o=>{rx.fillStyle='#42d6a4';rx.fillRect(o.x-10,o.y-10,20,20);rx.strokeStyle='#b5ffe5';rx.strokeRect(o.x-10,o.y-10,20,20)})}drawRoom();
rc.onclick=e=>{if(!placing)return;let r=rc.getBoundingClientRect();objects.push({x:Math.round((e.clientX-r.left)/r.width*640/32)*32+16,y:Math.round((e.clientY-r.top)/r.height*420/32)*32+16});drawRoom()};
$('#addobj').onclick=()=>{placing=!placing;$('#addobj').textContent=placing?'Tap room to place…':'＋ Place object'};
$('#roomgrid').onclick=()=>{showGrid=!showGrid;$('#roomgrid').textContent='Grid: '+(showGrid?'on':'off');drawRoom()};$('#clearroom').onclick=()=>{objects=[];drawRoom()};
function save(){localStorage.setItem('mgm_project',JSON.stringify({code:source.value,sprite:cv.toDataURL(),objects,frames}));alert('Project saved on this device.')}
$('#save').onclick=save;$('#exportproject').onclick=()=>{let data=localStorage.getItem('mgm_project')||JSON.stringify({code:source.value,sprite:cv.toDataURL(),objects,frames});let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download='my-game-project.json';a.click()};
$('#newasset').onclick=()=>alert('Asset type creation is planned for the next build.');try{let d=JSON.parse(localStorage.getItem('mgm_project'));if(d){source.value=d.code||source.value;paintCode();if(d.sprite){let im=new Image();im.onload=()=>ctx.drawImage(im,0,0);im.src=d.sprite}objects=d.objects||[];drawRoom()}}catch(e){}
