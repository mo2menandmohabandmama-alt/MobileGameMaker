# Mobile GameMaker-style IDE (Android starter)

This is an Android Studio project scaffold containing a touch-first, offline IDE prototype.

## Included
- Android WebView shell (Kotlin)
- Local HTML/CSS/JavaScript IDE interface
- GML-oriented code editor with basic syntax coloring and starter snippets
- Pixel sprite canvas with pencil/eraser, color picker, frame strip and PNG export
- Asset/project sidebar and room canvas prototype
- Local project persistence in browser storage

## Important compatibility note
This is **not GameMaker Studio 2** and does not contain YoYo Games' proprietary compiler/runtime.
The editor accepts GML text and provides basic GML-oriented editing, but true GML compilation,
debugging, asset import compatibility and exporting GameMaker games require licensed
GameMaker technology or a separately implemented compatible runtime. No APK is prebuilt.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

The project uses Android Gradle Plugin 8.6.1 and Kotlin 2.0.21. Android Studio may
prompt you to install a matching Android SDK platform.

## Build APK using GitHub Actions (no Android SDK needed on your phone)
1. Upload this project folder to a GitHub repository.
2. Open the repository's **Actions** tab and run **Build Android APK** (or push to main/master).
3. Open the completed workflow run and download the `mobile-gamemaker-debug-apk` artifact.
4. Extract `app-debug.apk` and install it on your Android device (allow installation from that source if Android asks).

This workflow creates a debug APK, not a Play Store release-signed APK.
